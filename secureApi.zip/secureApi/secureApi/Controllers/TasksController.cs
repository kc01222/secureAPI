﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/tasks")]
[Authorize]
public class TasksController : ControllerBase
{
    private readonly AppDbContext _db;

    public TasksController(AppDbContext db)
    {
        _db = db;
    }

    [HttpPost]
    public async Task<IActionResult> Create(TaskItem task)
    {
        task.OwnerId = User.FindFirstValue(ClaimTypes.NameIdentifier)!;
        _db.Tasks.Add(task);
        await _db.SaveChangesAsync();
        return Ok(task);
    }

    [HttpGet]
    public IActionResult GetMine()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Ok(_db.Tasks.Where(t => t.OwnerId == userId));
    }
}
